<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
  </head>
  <body>
    <footer id="footer">
      <hr>
      <p>© 2018 AchèteUneLicorne</p>
    </footer>
  </body>
</html>
