<?php

    // Un produit en vente
    class Produit {
      public $reference;      // Référence unique
      public $intitule;       // Nom du produit
      public $informations;   // Informations supplémentaires
      public $categorie;      // Catégorie du produit
      public $prix;           // Prix du produit
      public $image;          // Nom du fichier image
    }

?>
