<?php

    // Une catégorie de produits
    class Categorie {
      public $numero;   // Numero de catégorie (identifiant)
      public $nom;      // Nom de la catégorie
      public $parent;   // Catégorie parente
    }

?>
