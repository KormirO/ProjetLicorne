<?php
header('Location: controler/accueil.ctrl.php');
